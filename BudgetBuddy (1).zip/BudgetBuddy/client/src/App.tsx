import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import DailyBudget from "@/pages/DailyBudget";
import MonthlyStats from "@/pages/MonthlyStats";
import TrackExpenses from "@/pages/TrackExpenses";
import Budget from "@/pages/Budget";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/daily-budget" component={DailyBudget} />
      <Route path="/monthly-stats" component={MonthlyStats} />
      <Route path="/track-expenses" component={TrackExpenses} />
      <Route path="/budget" component={Budget} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
