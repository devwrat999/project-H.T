import React from 'react';
import { SimpleBarChart } from '@/components/ui/chart';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';

export default function MonthlyExpenseChart() {
  const { data: monthlyExpenses, isLoading } = useQuery({
    queryKey: ['/api/expenses/monthly'],
  });

  // Format the data for the chart
  const chartData = monthlyExpenses ? 
    Object.entries(monthlyExpenses).map(([month, value]) => ({
      name: month,
      value: value
    })) : 
    [
      { name: 'Jan', value: 0 },
      { name: 'Feb', value: 0 },
      { name: 'Mar', value: 0 },
      { name: 'Apr', value: 0 },
      { name: 'May', value: 0 }
    ];

  return (
    <section className="container mx-auto px-4 mt-8 mb-10">
      <Card className="bg-light rounded-lg shadow-md">
        <CardContent className="p-6">
          <h2 className="text-2xl font-bold mb-6">Monthly Expense Comparison</h2>
          <div className="h-64 md:h-80">
            {isLoading ? (
              <div className="flex h-full items-center justify-center">
                <p>Loading chart data...</p>
              </div>
            ) : (
              <SimpleBarChart 
                data={chartData} 
                dataKey="value" 
                xDataKey="name"
                barColor="#9370DB" 
              />
            )}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
