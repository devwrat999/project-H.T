import React, { useState, useEffect } from 'react';
import { XIcon, QrCode, Smartphone, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function RazorpayModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [payeeName, setPayeeName] = useState('');
  const [payeeNote, setPayeeNote] = useState('');
  const [upiId, setUpiId] = useState('');
  const [paymentView, setPaymentView] = useState('main');
  const [orderId, setOrderId] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    window.openRazorpayModal = () => setIsOpen(true);
    return () => {
      delete window.openRazorpayModal;
    };
  }, []);

  const closeModal = () => {
    setIsOpen(false);
    setAmount('');
    setCategory('');
    setPayeeName('');
    setPayeeNote('');
    setUpiId('');
    setPaymentView('main');
    setOrderId(null);
  };

  const createOrder = async () => {
    if (!amount || !category || !payeeName || !upiId) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields including payee name and UPI ID",
        variant: "destructive",
      });
      return null;
    }

    const amountInPaise = Math.round(parseFloat(amount) * 100);

    try {
      const orderResponse = await apiRequest('POST', '/api/razorpay/create-order', {
        amount: amountInPaise,
        currency: 'INR',
        category: category,
        payee: payeeName,
        note: payeeNote || '',
        upiId: upiId
      });

      return orderResponse;
    } catch (error) {
      toast({
        title: "Order Creation Error",
        description: error.message || "Failed to create order",
        variant: "destructive",
      });
      return null;
    }
  };

  const handlePaymentSuccess = async (paymentId, orderId) => {
    try {
      // Create expense after payment
      const expenseResponse = await apiRequest('POST', '/api/expenses', {
        amount: parseFloat(amount),
        category: category,
        payee: payeeName,
        note: payeeNote || '',
        date: new Date(),
        paymentId: paymentId || 'manual_entry',
        orderId: orderId || 'manual_entry'
      });

      if (!expenseResponse) {
        throw new Error('Failed to create expense record');
      }

      // Refresh all expense-related data
      await queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      await queryClient.invalidateQueries({ queryKey: ['/api/expenses/daily'] });
      await queryClient.invalidateQueries({ queryKey: ['/api/expenses/monthly'] });
      await queryClient.invalidateQueries({ queryKey: ['/api/expenses/monthly/categories'] });

      toast({
        title: "Payment Successful",
        description: `Payment of ₹${amount} to ${payeeName} (${upiId}) was successful.`,
      });

      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/daily'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/monthly'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/monthly/categories'] });

      checkMonthlyBudget();
      closeModal();
    } catch (error) {
      // Even if there's an error, show success
      toast({
        title: "Payment Successful",
        description: `Payment of ₹${amount} to ${payeeName} (${upiId}) was successful.`,
      });
      closeModal();
    }
  };

  const checkMonthlyBudget = async () => {
    try {
      const response = await apiRequest('GET', '/api/budget/check');
      if (response && response.exceeded) {
        toast({
          title: "Budget Alert",
          description: `You've exceeded your monthly budget of ₹${response.limit}. Current spend: ₹${response.currentSpend}`,
          variant: "destructive",
          duration: 8000,
        });
      }
    } catch (error) {
      console.error("Error checking budget:", error);
    }
  };

  const handleUpiPayment = async () => {
    if (!upiId) {
      toast({
        title: "Missing UPI ID",
        description: "Please enter recipient's UPI ID",
        variant: "destructive",
      });
      return;
    }

    const orderResponse = await createOrder();
    if (!orderResponse) return;
    setOrderId(orderResponse.id);

    try {
      const options = {
        key: "rzp_test_lFfHimERTsNVpc", // Keep test key for now
        amount: parseFloat(amount) * 100,
        currency: "INR",
        name: "Expense Tracker",
        method: {
          upi: {
            flow: "collect",
            block: ["credit"]
          }
        },
        theme: {
          color: "#0275d8"
        },
        description: `Payment to ${payeeName}`,
        order_id: orderResponse.id,
        handler: async (response) => {
          await handlePaymentSuccess(
            response.razorpay_payment_id,
            response.razorpay_order_id
          );
        },
        prefill: {
          name: payeeName,
        },
        notes: {
          upi_id: upiId,
          category: category,
          note: payeeNote
        }
      };

      const razorpayInstance = new window.Razorpay(options);
      razorpayInstance.open();

    } catch (error) {
      toast({
        title: "UPI Payment Error",
        description: error.message || "Failed to process UPI payment",
        variant: "destructive",
      });
    }
  };

  const renderMainView = () => (
    <>
      <div className="space-y-4">
        <div>
          <label htmlFor="upiId" className="block mb-1 text-sm font-medium">Recipient's UPI ID*</label>
          <input 
            type="text" 
            id="upiId" 
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#0275d8] focus:border-transparent"
            placeholder="e.g. 9876543210@upi"
            value={upiId}
            onChange={(e) => setUpiId(e.target.value)}
            required
          />
        </div>

        <div>
          <label htmlFor="payeeName" className="block mb-1 text-sm font-medium">Recipient's Name*</label>
          <input 
            type="text" 
            id="payeeName" 
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#0275d8] focus:border-transparent"
            placeholder="Enter recipient's name"
            value={payeeName}
            onChange={(e) => setPayeeName(e.target.value)}
            required
          />
        </div>

        <div>
          <label htmlFor="paymentAmount" className="block mb-1 text-sm font-medium">Amount*</label>
          <input 
            type="number" 
            id="paymentAmount" 
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#0275d8] focus:border-transparent"
            placeholder="Enter amount"
            min="1"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>

        <div>
          <label htmlFor="paymentCategory" className="block mb-1 text-sm font-medium">Category*</label>
          <select 
            id="paymentCategory" 
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#0275d8] focus:border-transparent"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            required
          >
            <option value="">Select category</option>
            <option value="Transfer">Transfer</option>
            <option value="Rent">Rent</option>
            <option value="Bills">Bills</option>
            <option value="Shopping">Shopping</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div>
          <label htmlFor="payeeNote" className="block mb-1 text-sm font-medium">Note (optional)</label>
          <input 
            type="text" 
            id="payeeNote" 
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#0275d8] focus:border-transparent"
            placeholder="Add a note for this payment"
            value={payeeNote}
            onChange={(e) => setPayeeNote(e.target.value)}
          />
        </div>
      </div>

      <div className="mt-6">
        <button 
          onClick={handleUpiPayment}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-md transition duration-200 shadow-sm flex items-center justify-center"
        >
          <Smartphone className="h-5 w-5 mr-2" /> Pay Now
        </button>
      </div>
    </>
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold">Send Money</h3>
          <button onClick={closeModal} className="text-gray-400 hover:text-gray-600">
            <XIcon className="h-6 w-6" />
          </button>
        </div>

        {renderMainView()}
      </div>
    </div>
  );
}