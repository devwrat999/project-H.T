import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { PlusIcon } from "lucide-react";

export default function ExpenseForm({ onAddExpense }) {
  const [category, setCategory] = useState('');
  const [amount, setAmount] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!category || !amount) {
      toast({
        title: "Missing fields",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      toast({
        title: "Invalid amount",
        description: "Amount must be a positive number",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await apiRequest('POST', '/api/expenses', {
        category,
        amount: amountNum,
        date: new Date().toISOString()
      });

      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/daily'] });
      queryClient.invalidateQueries({ queryKey: ['/api/expenses/monthly'] });
      
      setCategory('');
      setAmount('');
      
      toast({
        title: "Expense added",
        description: `Added ₹${amountNum} for ${category}`,
      });

      if (onAddExpense) {
        onAddExpense({ category, amount: amountNum });
      }
      
    } catch (error) {
      toast({
        title: "Error adding expense",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label htmlFor="category" className="block mb-1 text-sm font-medium">Category</label>
          <input 
            type="text" 
            id="category" 
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#00b894] focus:border-transparent"
            placeholder="Food, Transport, etc."
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="amount" className="block mb-1 text-sm font-medium">Amount</label>
          <input 
            type="number" 
            id="amount" 
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#00b894] focus:border-transparent"
            placeholder="Enter amount"
            min="1"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
      </div>
      <button 
        type="submit" 
        className="bg-[#00b894] hover:bg-green-600 text-white py-2 px-4 rounded-md transition duration-200 shadow-sm flex items-center"
      >
        <PlusIcon className="h-5 w-5 mr-1" />
        Add Expense
      </button>
    </form>
  );
}
