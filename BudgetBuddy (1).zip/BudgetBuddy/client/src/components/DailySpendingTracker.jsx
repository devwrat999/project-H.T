import React, { useEffect, useState } from 'react';
import { SimplePieChart } from '@/components/ui/chart';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import ExpenseForm from './ExpenseForm';

export default function DailySpendingTracker() {
  const [dailyTotal, setDailyTotal] = useState(0);
  const [dailyExpenseData, setDailyExpenseData] = useState([]);
  
  const { data: dailyExpenses, isLoading } = useQuery({
    queryKey: ['/api/expenses/daily'],
  });

  useEffect(() => {
    if (dailyExpenses) {
      const formattedData = Object.entries(dailyExpenses.categories || {}).map(([category, amount]) => ({
        name: category,
        value: amount
      }));
      
      setDailyExpenseData(formattedData);
      setDailyTotal(dailyExpenses.total || 0);
    }
  }, [dailyExpenses]);

  const chartColors = ["#0275d8", "#00b894", "#ffc107", "#fd7e14", "#6c757d", "#e83e8c"];
  
  const handleAddExpense = (newExpense) => {
    // Update the UI immediately for better UX while the query is invalidating
    const existingCategoryIndex = dailyExpenseData.findIndex(
      item => item.name === newExpense.category
    );
    
    if (existingCategoryIndex >= 0) {
      const updatedData = [...dailyExpenseData];
      updatedData[existingCategoryIndex].value += parseFloat(newExpense.amount);
      setDailyExpenseData(updatedData);
    } else {
      setDailyExpenseData([
        ...dailyExpenseData,
        { name: newExpense.category, value: parseFloat(newExpense.amount) }
      ]);
    }
    
    setDailyTotal(prevTotal => prevTotal + parseFloat(newExpense.amount));
  };

  return (
    <Card className="bg-light rounded-lg shadow-md h-full">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Daily Spending Pie Chart (Limit: ₹250)</h2>
        
        <ExpenseForm onAddExpense={handleAddExpense} />
        
        <div className="h-52 mb-4">
          {isLoading ? (
            <div className="flex h-full items-center justify-center">
              <p>Loading chart data...</p>
            </div>
          ) : (
            <SimplePieChart 
              data={dailyExpenseData} 
              colors={chartColors}
              height={180}
            />
          )}
        </div>

        <div className="mt-4 text-right">
          <p className={`text-lg font-semibold ${dailyTotal > 250 ? 'text-red-600' : ''}`}>
            Total Spent: <span className="font-mono">₹{dailyTotal}</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
