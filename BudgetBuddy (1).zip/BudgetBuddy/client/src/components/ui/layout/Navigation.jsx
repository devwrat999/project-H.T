import React from 'react';
import { Link, useLocation } from 'wouter';

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="container mx-auto px-4 py-4">
      <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
        <Link href="/">
          <a className={`bg-[#0275d8] hover:bg-blue-600 text-white py-3 rounded-md transition duration-200 shadow-sm text-center`}>
            Dashboard
          </a>
        </Link>
        <Link href="/daily-budget">
          <a className={`bg-[#0275d8] hover:bg-blue-600 text-white py-3 rounded-md transition duration-200 shadow-sm text-center`}>
            Daily Budget
          </a>
        </Link>
        <Link href="/monthly-stats">
          <a className={`bg-[#0275d8] hover:bg-blue-600 text-white py-3 rounded-md transition duration-200 shadow-sm text-center`}>
            Monthly Stats
          </a>
        </Link>
        <Link href="/track-expenses">
          <a className={`bg-[#0275d8] hover:bg-blue-600 text-white py-3 rounded-md transition duration-200 shadow-sm text-center`}>
            Track Expenses
          </a>
        </Link>
        <Link href="/budget">
          <a className={`bg-[#0275d8] hover:bg-blue-600 text-white py-3 rounded-md transition duration-200 shadow-sm text-center`}>
            Budget Settings
          </a>
        </Link>
        <button
          onClick={() => window.openRazorpayModal()}
          className="bg-green-600 hover:bg-green-700 text-white py-3 rounded-md transition duration-200 shadow-sm text-center font-semibold"
        >
          Make Payment
        </button>
      </div>
      
      <div className="mt-2 flex justify-end">
        <button 
          onClick={() => window.downloadReport()}
          className="text-[#0275d8] hover:text-blue-700 text-sm flex items-center"
        >
          Download Expense Report
        </button>
      </div>
    </nav>
  );
}
