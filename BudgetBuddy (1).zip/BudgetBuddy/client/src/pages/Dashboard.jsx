import React, { useEffect } from 'react';
import Header from '@/components/ui/layout/Header';
import Navigation from '@/components/ui/layout/Navigation';
import MonthlyExpenseChart from '@/components/MonthlyExpenseChart';
import MonthlyPieChart from '@/components/MonthlyPieChart';
import DailySpendingTracker from '@/components/DailySpendingTracker';
import RazorpayModal from '@/components/RazorpayModal';

export default function Dashboard() {
  useEffect(() => {
    // Set up report download function
    window.downloadReport = async () => {
      try {
        const response = await fetch('/api/reports/download');
        if (response.ok) {
          const blob = await response.blob();
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.style.display = 'none';
          a.href = url;
          a.download = 'expense-report.csv';
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);
        } else {
          alert('Failed to download report');
        }
      } catch (error) {
        console.error('Error downloading report:', error);
        alert('Error downloading report');
      }
    };

    return () => {
      delete window.downloadReport;
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Navigation />
      
      <MonthlyExpenseChart />
      
      <section className="container mx-auto px-4 my-10 grid grid-cols-1 md:grid-cols-2 gap-8">
        <MonthlyPieChart />
        <DailySpendingTracker />
      </section>
      
      <RazorpayModal />
    </div>
  );
}
