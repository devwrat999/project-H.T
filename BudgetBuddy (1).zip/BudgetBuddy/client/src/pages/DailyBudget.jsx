import React from 'react';
import Header from '@/components/ui/layout/Header';
import Navigation from '@/components/ui/layout/Navigation';
import DailySpendingTracker from '@/components/DailySpendingTracker';
import RazorpayModal from '@/components/RazorpayModal';

export default function DailyBudget() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Navigation />
      
      <section className="container mx-auto px-4 my-10">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Daily Budget</h1>
          <DailySpendingTracker />
        </div>
      </section>
      
      <RazorpayModal />
    </div>
  );
}
