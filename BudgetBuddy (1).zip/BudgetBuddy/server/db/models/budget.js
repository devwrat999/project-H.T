const mongoose = require('mongoose');

// Schema for budget settings
const budgetSchema = new mongoose.Schema({
  limit: {
    type: Number,
    required: true,
    min: 1
  },
  month: {
    type: Number,
    required: true,
    min: 0,
    max: 11 // 0-11 for Jan-Dec
  },
  year: {
    type: Number,
    required: true
  },
  // Allow only one budget record per month/year combination
  userId: {
    type: String,
    default: 'default' // For a single-user system
  }
}, {
  timestamps: true
});

// Create a compound index for month and year to ensure uniqueness
budgetSchema.index({ month: 1, year: 1, userId: 1 }, { unique: true });

// Create the model
const Budget = mongoose.model('Budget', budgetSchema);

module.exports = Budget;