const mongoose = require('mongoose');

// Schema for Razorpay orders
const razorpayOrderSchema = new mongoose.Schema({
  orderId: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  currency: {
    type: String,
    required: true,
    default: 'INR',
    trim: true
  },
  status: {
    type: String,
    required: true,
    enum: ['created', 'paid', 'failed', 'refunded'],
    default: 'created'
  },
  category: {
    type: String,
    required: true,
    trim: true
  },
  payee: {
    type: String,
    trim: true
  },
  note: {
    type: String,
    trim: true
  }
}, {
  timestamps: true // Adds createdAt and updatedAt
});

// Create indexes for common queries
razorpayOrderSchema.index({ orderId: 1 }, { unique: true });
razorpayOrderSchema.index({ status: 1 });
razorpayOrderSchema.index({ createdAt: 1 });

// Create the model
const RazorpayOrder = mongoose.model('RazorpayOrder', razorpayOrderSchema);

module.exports = RazorpayOrder;