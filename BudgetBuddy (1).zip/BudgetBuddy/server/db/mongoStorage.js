const Expense = require('./models/expense');
const RazorpayOrder = require('./models/razorpayOrder');
const Budget = require('./models/budget');
const { IStorage } = require('../storage');

/**
 * MongoDB storage implementation that follows the same interface as MemStorage
 */
class MongoStorage {
  /**
   * Get all expenses ordered by date (newest first)
   */
  async getExpenses() {
    try {
      return await Expense.find({}).sort({ date: -1 });
    } catch (error) {
      console.error('Error getting expenses:', error);
      return [];
    }
  }

  /**
   * Get expense by ID
   */
  async getExpenseById(id) {
    try {
      return await Expense.findById(id);
    } catch (error) {
      console.error(`Error getting expense with ID ${id}:`, error);
      return undefined;
    }
  }

  /**
   * Get daily expenses for a specific date
   */
  async getDailyExpenses(date = new Date()) {
    try {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      
      return await Expense.find({
        date: { 
          $gte: startOfDay, 
          $lte: endOfDay 
        }
      }).sort({ date: -1 });
    } catch (error) {
      console.error('Error getting daily expenses:', error);
      return [];
    }
  }

  /**
   * Get monthly expenses for a specific month and year
   */
  async getMonthlyExpenses(month = new Date().getMonth(), year = new Date().getFullYear()) {
    try {
      const startOfMonth = new Date(year, month, 1);
      const endOfMonth = new Date(year, month + 1, 0, 23, 59, 59, 999);
      
      return await Expense.find({
        date: { 
          $gte: startOfMonth, 
          $lte: endOfMonth 
        }
      }).sort({ date: -1 });
    } catch (error) {
      console.error('Error getting monthly expenses:', error);
      return [];
    }
  }

  /**
   * Create a new expense
   */
  async createExpense(expenseData) {
    try {
      const expense = new Expense({
        category: expenseData.category,
        amount: typeof expenseData.amount === 'string' ? parseFloat(expenseData.amount) : expenseData.amount,
        date: expenseData.date || new Date(),
        paymentId: expenseData.paymentId,
        orderId: expenseData.orderId,
        payee: expenseData.payee || null,
        note: expenseData.note || null
      });
      
      await expense.save();
      return expense;
    } catch (error) {
      console.error('Error creating expense:', error);
      throw error;
    }
  }

  /**
   * Create a new Razorpay order
   */
  async createRazorpayOrder(orderData) {
    try {
      const order = new RazorpayOrder({
        orderId: orderData.orderId,
        amount: typeof orderData.amount === 'string' ? parseFloat(orderData.amount) : orderData.amount,
        currency: orderData.currency,
        status: orderData.status,
        category: orderData.category,
        payee: orderData.payee || null,
        note: orderData.note || null
      });
      
      await order.save();
      return order;
    } catch (error) {
      console.error('Error creating Razorpay order:', error);
      throw error;
    }
  }

  /**
   * Get a Razorpay order by its order ID
   */
  async getRazorpayOrderById(orderId) {
    try {
      return await RazorpayOrder.findOne({ orderId });
    } catch (error) {
      console.error(`Error getting Razorpay order with ID ${orderId}:`, error);
      return undefined;
    }
  }

  /**
   * Update Razorpay order status
   */
  async updateRazorpayOrderStatus(orderId, status) {
    try {
      const order = await RazorpayOrder.findOne({ orderId });
      if (!order) return undefined;
      
      order.status = status;
      await order.save();
      return order;
    } catch (error) {
      console.error(`Error updating Razorpay order status for ID ${orderId}:`, error);
      return undefined;
    }
  }

  /**
   * Get current budget for a specific month and year
   */
  async getBudget(month = new Date().getMonth(), year = new Date().getFullYear()) {
    try {
      let budget = await Budget.findOne({ 
        month, 
        year,
        userId: 'default'
      });

      // If no budget found, get the default budget or create one
      if (!budget) {
        // Default budget is 10,000 INR
        budget = new Budget({
          limit: 10000,
          month,
          year,
          userId: 'default'
        });
        await budget.save();
      }

      return budget;
    } catch (error) {
      console.error('Error getting budget:', error);
      // Return a default budget if error occurs
      return { limit: 10000, month, year };
    }
  }

  /**
   * Update or create budget for a specific month and year
   */
  async setBudget(limit, month = new Date().getMonth(), year = new Date().getFullYear()) {
    try {
      const budget = await Budget.findOneAndUpdate(
        { month, year, userId: 'default' },
        { limit },
        { new: true, upsert: true }
      );
      return budget;
    } catch (error) {
      console.error('Error setting budget:', error);
      throw error;
    }
  }
}

module.exports = MongoStorage;