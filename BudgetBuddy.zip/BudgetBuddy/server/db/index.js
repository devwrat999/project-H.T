const { connectDB } = require('./mongoose');
const MongoStorage = require('./mongoStorage');

module.exports = {
  connectDB,
  MongoStorage
};