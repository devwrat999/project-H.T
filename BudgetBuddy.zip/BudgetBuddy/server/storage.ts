import { expenses, type Expense, type InsertExpense, razorpayOrders, type RazorpayOrder, type InsertRazorpayOrder, type BudgetSettings } from "@shared/schema";
// For now, we'll only declare the MongoStorage import, but implement it later
// We'll use MemStorage as the default until we convert the MongoDB code to ESM

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // Expense methods
  getExpenses(): Promise<Expense[]>;
  getExpenseById(id: number): Promise<Expense | undefined>;
  getDailyExpenses(date?: Date): Promise<Expense[]>;
  getMonthlyExpenses(month?: number, year?: number): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  
  // Razorpay methods
  createRazorpayOrder(order: InsertRazorpayOrder): Promise<RazorpayOrder>;
  getRazorpayOrderById(orderId: string): Promise<RazorpayOrder | undefined>;
  updateRazorpayOrderStatus(orderId: string, status: string): Promise<RazorpayOrder | undefined>;
  
  // Budget methods
  getBudget(month?: number, year?: number): Promise<BudgetSettings>;
  setBudget(limit: number, month?: number, year?: number): Promise<BudgetSettings>;
}

export class MemStorage implements IStorage {
  private expenses: Map<number, Expense>;
  private razorpayOrders: Map<string, RazorpayOrder>;
  currentExpenseId: number;
  currentOrderId: number;
  monthlyBudget: number;

  constructor() {
    this.expenses = new Map();
    this.razorpayOrders = new Map();
    this.currentExpenseId = 1;
    this.currentOrderId = 1;
    this.monthlyBudget = 10000; // Default budget is 10,000 INR
  }

  async getExpenses(): Promise<Expense[]> {
    return Array.from(this.expenses.values())
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getExpenseById(id: number): Promise<Expense | undefined> {
    return this.expenses.get(id);
  }

  async getDailyExpenses(date: Date = new Date()): Promise<Expense[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return Array.from(this.expenses.values()).filter(expense => {
      const expenseDate = new Date(expense.date);
      return expenseDate >= startOfDay && expenseDate <= endOfDay;
    });
  }

  async getMonthlyExpenses(month: number = new Date().getMonth(), year: number = new Date().getFullYear()): Promise<Expense[]> {
    return Array.from(this.expenses.values()).filter(expense => {
      const expenseDate = new Date(expense.date);
      return expenseDate.getMonth() === month && expenseDate.getFullYear() === year;
    });
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const id = this.currentExpenseId++;
    
    // Convert amount to the right format (always handle as number internally)
    const amountValue = typeof insertExpense.amount === 'string' 
      ? parseFloat(insertExpense.amount) 
      : insertExpense.amount;
    
    const expense: Expense = { 
      ...insertExpense, 
      id,
      amount: amountValue,
      // Make sure optional fields exist
      payee: insertExpense.payee || null,
      note: insertExpense.note || null
    };
    
    this.expenses.set(id, expense);
    return expense;
  }

  async createRazorpayOrder(insertOrder: InsertRazorpayOrder): Promise<RazorpayOrder> {
    const id = this.currentOrderId++;
    
    // Convert amount to the right format
    const amountValue = typeof insertOrder.amount === 'string' 
      ? parseFloat(insertOrder.amount) 
      : insertOrder.amount;
    
    const order: RazorpayOrder = { 
      ...insertOrder, 
      id,
      amount: amountValue,
      payee: insertOrder.payee || null,
      note: insertOrder.note || null,
      createdAt: new Date()
    };
    
    this.razorpayOrders.set(order.orderId, order);
    return order;
  }

  async getRazorpayOrderById(orderId: string): Promise<RazorpayOrder | undefined> {
    return this.razorpayOrders.get(orderId);
  }

  async updateRazorpayOrderStatus(orderId: string, status: string): Promise<RazorpayOrder | undefined> {
    const order = this.razorpayOrders.get(orderId);
    if (order) {
      const updatedOrder = { ...order, status };
      this.razorpayOrders.set(orderId, updatedOrder);
      return updatedOrder;
    }
    return undefined;
  }
  
  async getBudget(month: number = new Date().getMonth(), year: number = new Date().getFullYear()): Promise<BudgetSettings> {
    return { 
      limit: this.monthlyBudget,
      month,
      year
    };
  }
  
  async setBudget(limit: number, month: number = new Date().getMonth(), year: number = new Date().getFullYear()): Promise<BudgetSettings> {
    this.monthlyBudget = limit;
    return {
      limit,
      month,
      year
    };
  }
}

// For now, just use the MemStorage implementation
// We will implement MongoDB storage properly in a future update 
// by converting it to use ES modules
export const storage = new MemStorage();
