import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertExpenseSchema } from "@shared/schema";
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

// Default monthly budget (can be overridden)
let monthlyBudget = 10000; // 10,000 INR

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix with /api
  const apiRouter = express.Router();

  // Expenses Routes
  apiRouter.get('/expenses', async (req, res) => {
    try {
      const expenses = await storage.getExpenses();
      res.json(expenses);
    } catch (error) {
      console.error('Error fetching expenses:', error);
      res.status(500).json({ error: 'Failed to fetch expenses' });
    }
  });

  apiRouter.get('/expenses/daily', async (req, res) => {
    try {
      const date = req.query.date ? new Date(req.query.date as string) : new Date();
      const expenses = await storage.getDailyExpenses(date);
      
      // Calculate total and categorize expenses
      let total = 0;
      const categories: Record<string, number> = {};
      
      expenses.forEach(expense => {
        total += parseFloat(expense.amount.toString());
        
        if (categories[expense.category]) {
          categories[expense.category] += parseFloat(expense.amount.toString());
        } else {
          categories[expense.category] = parseFloat(expense.amount.toString());
        }
      });
      
      res.json({
        total,
        categories,
        expenses
      });
    } catch (error) {
      console.error('Error fetching daily expenses:', error);
      res.status(500).json({ error: 'Failed to fetch daily expenses' });
    }
  });

  apiRouter.get('/expenses/monthly', async (req, res) => {
    try {
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      // Get expenses for the last 5 months
      const monthlyData: Record<string, number> = {};
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      
      for (let i = 0; i < 5; i++) {
        let month = currentMonth - i;
        let year = currentYear;
        
        if (month < 0) {
          month += 12;
          year -= 1;
        }
        
        const expenses = await storage.getMonthlyExpenses(month, year);
        const total = expenses.reduce((sum, expense) => 
          sum + parseFloat(expense.amount.toString()), 0);
        
        monthlyData[monthNames[month]] = total;
      }
      
      res.json(monthlyData);
    } catch (error) {
      console.error('Error fetching monthly expenses:', error);
      res.status(500).json({ error: 'Failed to fetch monthly expenses' });
    }
  });

  apiRouter.get('/expenses/monthly/categories', async (req, res) => {
    try {
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      const expenses = await storage.getMonthlyExpenses(currentMonth, currentYear);
      
      // Group by category
      const categories: Record<string, number> = {};
      
      expenses.forEach(expense => {
        if (categories[expense.category]) {
          categories[expense.category] += parseFloat(expense.amount.toString());
        } else {
          categories[expense.category] = parseFloat(expense.amount.toString());
        }
      });
      
      res.json(categories);
    } catch (error) {
      console.error('Error fetching category expenses:', error);
      res.status(500).json({ error: 'Failed to fetch category expenses' });
    }
  });

  apiRouter.post('/expenses', async (req, res) => {
    try {
      const expenseSchema = insertExpenseSchema.extend({
        payee: z.string().optional(),
        note: z.string().optional()
      });
      
      const expenseData = expenseSchema.parse(req.body);
      const expense = await storage.createExpense(expenseData);
      res.status(201).json(expense);
    } catch (error) {
      console.error('Error creating expense:', error);
      res.status(400).json({ error: 'Invalid expense data' });
    }
  });

  // Budget Routes
  apiRouter.get('/budget', async (req, res) => {
    try {
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      // Get the budget for the current month/year
      const budget = await storage.getBudget(currentMonth, currentYear);
      
      const expenses = await storage.getMonthlyExpenses(currentMonth, currentYear);
      const currentSpend = expenses.reduce((total, expense) => 
        total + parseFloat(expense.amount.toString()), 0);
      
      // Get month name
      const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                          'July', 'August', 'September', 'October', 'November', 'December'];
      
      res.json({
        limit: budget.limit,
        currentSpend,
        month: monthNames[currentMonth],
        year: currentYear,
        remaining: Math.max(0, budget.limit - currentSpend),
        exceeded: currentSpend > budget.limit
      });
    } catch (error) {
      console.error('Error fetching budget:', error);
      res.status(500).json({ error: 'Failed to fetch budget information' });
    }
  });

  apiRouter.post('/budget/set', async (req, res) => {
    try {
      const schema = z.object({
        limit: z.number().min(1)
      });
      
      const { limit } = schema.parse(req.body);
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      // Set the budget for the current month/year
      const budget = await storage.setBudget(limit, currentMonth, currentYear);
      
      res.json({
        success: true,
        limit: budget.limit
      });
    } catch (error) {
      console.error('Error setting budget:', error);
      res.status(400).json({ error: 'Invalid budget data' });
    }
  });

  apiRouter.get('/budget/check', async (req, res) => {
    try {
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      // Get the budget for the current month/year
      const budget = await storage.getBudget(currentMonth, currentYear);
      
      const expenses = await storage.getMonthlyExpenses(currentMonth, currentYear);
      const currentSpend = expenses.reduce((total, expense) => 
        total + parseFloat(expense.amount.toString()), 0);
      
      res.json({
        limit: budget.limit,
        currentSpend,
        exceeded: currentSpend > budget.limit
      });
    } catch (error) {
      console.error('Error checking budget:', error);
      res.status(500).json({ error: 'Failed to check budget' });
    }
  });

  // Razorpay Routes
  apiRouter.post('/razorpay/create-order', async (req, res) => {
    try {
      const schema = z.object({
        amount: z.number(),
        currency: z.string().default('INR'),
        category: z.string(),
        payee: z.string().optional(),
        note: z.string().optional()
      });
      
      const { amount, currency, category, payee, note } = schema.parse(req.body);
      
      // In a real implementation, you would use the Razorpay SDK
      // For this demo, we'll create a mock order
      const orderData = {
        orderId: `order_${Date.now()}`,
        amount,
        currency,
        status: 'created',
        category,
        payee: payee || 'Not specified',
        note: note || ''
      };
      
      const order = await storage.createRazorpayOrder(orderData);
      
      res.json({
        id: order.orderId,
        entity: 'order',
        amount: order.amount,
        currency: order.currency,
        status: order.status,
        category: order.category,
        payee: order.payee,
        note: order.note
      });
    } catch (error) {
      console.error('Error creating Razorpay order:', error);
      res.status(400).json({ error: 'Failed to create order' });
    }
  });

  apiRouter.post('/razorpay/verify-payment', async (req, res) => {
    try {
      const schema = z.object({
        razorpay_order_id: z.string().optional(),
        razorpay_payment_id: z.string().optional(),
        razorpay_signature: z.string().optional(),
        amount: z.number(),
        category: z.string(),
        payee: z.string().optional(),
        note: z.string().optional()
      });
      
      const { 
        razorpay_order_id, 
        razorpay_payment_id, 
        amount, 
        category,
        payee,
        note
      } = schema.parse(req.body);
      
      // Always create an expense record
      const expenseData = {
        category,
        amount,
        date: new Date(),
        paymentId: razorpay_payment_id || 'manual_entry',
        orderId: razorpay_order_id || 'manual_entry',
        payee: payee || 'Not specified',
        note: note || ''
      };
      
      const expense = await storage.createExpense(expenseData);
      
      // Check if we've exceeded the monthly budget
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      // Get the budget for the current month/year
      const budget = await storage.getBudget(currentMonth, currentYear);
      
      const expenses = await storage.getMonthlyExpenses(currentMonth, currentYear);
      const currentSpend = expenses.reduce((total, exp) => 
        total + parseFloat(exp.amount.toString()), 0);
      
      const budgetExceeded = currentSpend > budget.limit;
      
      res.json({
        success: true,
        expense,
        budget: {
          exceeded: budgetExceeded,
          limit: budget.limit,
          currentSpend
        }
      });
    } catch (error) {
      console.error('Error verifying payment:', error);
      res.status(400).json({ error: 'Payment verification failed' });
    }
  });

  // Reports
  apiRouter.get('/reports/download', async (req, res) => {
    try {
      const expenses = await storage.getExpenses();
      
      // Generate CSV content
      const headers = ['Date,Category,Amount,Payee,Note'];
      const rows = expenses.map(expense => {
        const date = new Date(expense.date).toLocaleDateString();
        const category = expense.category || '';
        const amount = expense.amount || 0;
        const payee = expense.payee || '';
        const note = expense.note || '';
        
        return `${date},${category},${amount},"${payee}","${note}"`;
      });
      
      const csvContent = [...headers, ...rows].join('\n');
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=expense-report.csv');
      
      res.send(csvContent);
    } catch (error) {
      console.error('Error generating report:', error);
      res.status(500).json({ error: 'Failed to generate report' });
    }
  });

  app.use('/api', apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
