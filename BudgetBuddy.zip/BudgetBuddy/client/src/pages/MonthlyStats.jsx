import React from 'react';
import Header from '@/components/ui/layout/Header';
import Navigation from '@/components/ui/layout/Navigation';
import MonthlyExpenseChart from '@/components/MonthlyExpenseChart';
import MonthlyPieChart from '@/components/MonthlyPieChart';
import RazorpayModal from '@/components/RazorpayModal';

export default function MonthlyStats() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Navigation />
      
      <section className="container mx-auto px-4 my-10">
        <h1 className="text-3xl font-bold mb-6">Monthly Statistics</h1>
        
        <div className="grid grid-cols-1 gap-8">
          <MonthlyExpenseChart />
          <MonthlyPieChart />
        </div>
      </section>
      
      <RazorpayModal />
    </div>
  );
}
