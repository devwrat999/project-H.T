import React from 'react';
import Header from '@/components/ui/layout/Header';
import Navigation from '@/components/ui/layout/Navigation';
import BudgetSettings from '@/components/BudgetSettings';
import RazorpayModal from '@/components/RazorpayModal';

export default function Budget() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Navigation />
      
      <section className="container mx-auto px-4 my-10">
        <h1 className="text-3xl font-bold mb-6">Budget Manager</h1>
        
        <div className="grid grid-cols-1 gap-8">
          <BudgetSettings />
        </div>
      </section>
      
      <RazorpayModal />
    </div>
  );
}