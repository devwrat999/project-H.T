import React from 'react';
import Header from '@/components/ui/layout/Header';
import Navigation from '@/components/ui/layout/Navigation';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { formatDate } from '@/lib/utils';
import RazorpayModal from '@/components/RazorpayModal';
import ExpenseForm from '@/components/ExpenseForm';

export default function TrackExpenses() {
  const { data: expenses, isLoading } = useQuery({
    queryKey: ['/api/expenses'],
  });

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Navigation />
      
      <section className="container mx-auto px-4 my-10">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Track Expenses</h1>
          
          <Card className="mb-8">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Add New Expense</h2>
              <ExpenseForm />
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Recent Expenses</h2>
              
              {isLoading ? (
                <p>Loading expenses...</p>
              ) : !expenses || expenses.length === 0 ? (
                <p>No expenses recorded yet. Add your first expense above.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {expenses.map((expense) => (
                      <TableRow key={expense.id}>
                        <TableCell>{formatDate(expense.date)}</TableCell>
                        <TableCell>{expense.category}</TableCell>
                        <TableCell className="text-right font-mono">₹{expense.amount}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </section>
      
      <RazorpayModal />
    </div>
  );
}
