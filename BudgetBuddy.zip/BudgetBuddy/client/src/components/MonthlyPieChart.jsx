import React from 'react';
import { SimplePieChart } from '@/components/ui/chart';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';

export default function MonthlyPieChart() {
  const { data: monthlyCategoryExpenses, isLoading } = useQuery({
    queryKey: ['/api/expenses/monthly/categories'],
  });

  // Format the data for the chart
  const chartData = monthlyCategoryExpenses ? 
    Object.entries(monthlyCategoryExpenses).map(([category, value]) => ({
      name: category,
      value: value
    })) : 
    [];

  const chartColors = ["#0275d8", "#00b894", "#ffc107", "#fd7e14", "#6c757d", "#e83e8c"];

  return (
    <Card className="bg-light rounded-lg shadow-md h-full">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Total Amount spent in Month</h2>
        {isLoading ? (
          <div className="flex h-40 items-center justify-center">
            <p>Loading chart data...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="h-64">
              <SimplePieChart 
                data={chartData} 
                colors={chartColors}
                legend={false}
              />
            </div>
            <div className="flex flex-col justify-center">
              <h3 className="text-lg font-semibold mb-3">Breakdown</h3>
              <div className="space-y-2">
                {chartData.map((category, index) => (
                  <div key={category.name} className="flex items-center">
                    <span 
                      className="w-3 h-3 rounded-full mr-2" 
                      style={{ backgroundColor: chartColors[index % chartColors.length] }}
                    ></span>
                    <span className="mr-2">{category.name}</span>
                    <span className="font-mono">₹{category.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
