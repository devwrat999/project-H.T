import React, { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle } from 'lucide-react';

export default function BudgetSettings() {
  const [budget, setBudget] = useState(null);
  const [newBudget, setNewBudget] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchBudget();
  }, []);

  const fetchBudget = async () => {
    try {
      setIsLoading(true);
      const response = await apiRequest('GET', '/api/budget');
      setBudget(response);
      setNewBudget(response.limit);
    } catch (error) {
      console.error('Error fetching budget:', error);
      toast({
        title: "Error",
        description: "Failed to load budget settings",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveBudget = async () => {
    if (!newBudget || isNaN(newBudget) || parseFloat(newBudget) <= 0) {
      toast({
        title: "Invalid input",
        description: "Please enter a valid budget amount greater than 0",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsSaving(true);
      const response = await apiRequest('POST', '/api/budget/set', {
        limit: parseFloat(newBudget)
      });

      if (response.success) {
        toast({
          title: "Budget Updated",
          description: `Monthly budget has been set to ₹${response.limit}`,
        });
        
        // Refresh budget data
        fetchBudget();
      }
    } catch (error) {
      console.error('Error saving budget:', error);
      toast({
        title: "Error",
        description: "Failed to save budget settings",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="bg-light rounded-lg shadow-md">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-6">Monthly Budget Settings</h2>
        
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <p>Loading budget information...</p>
          </div>
        ) : budget ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">Current Budget</h3>
                <div className="p-4 bg-gray-50 rounded-md">
                  <p className="mb-1 text-sm text-gray-600">Month: {budget.month} {budget.year}</p>
                  <p className="text-2xl font-bold">₹{budget.limit.toLocaleString()}</p>
                  
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <p className="flex justify-between">
                      <span>Spent so far:</span>
                      <span className="font-semibold">₹{budget.currentSpend.toLocaleString()}</span>
                    </p>
                    <p className="flex justify-between">
                      <span>Remaining:</span>
                      <span className={`font-semibold ${budget.exceeded ? 'text-red-600' : 'text-green-600'}`}>
                        {budget.exceeded ? '-' : ''}₹{Math.abs(budget.remaining).toLocaleString()}
                      </span>
                    </p>
                  </div>
                  
                  {budget.exceeded && (
                    <div className="mt-3 flex items-start text-red-600 text-sm">
                      <AlertCircle className="h-4 w-4 mr-1 mt-0.5" />
                      <span>You've exceeded your monthly budget!</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Update Budget</h3>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="budgetAmount" className="block mb-1 text-sm font-medium">
                      Monthly Budget Limit (₹)
                    </label>
                    <Input 
                      id="budgetAmount"
                      type="number"
                      placeholder="Enter amount"
                      value={newBudget}
                      onChange={(e) => setNewBudget(e.target.value)}
                      min="1"
                      className="w-full"
                    />
                  </div>
                  
                  <Button 
                    className="w-full"
                    onClick={handleSaveBudget}
                    disabled={isSaving}
                  >
                    {isSaving ? 'Saving...' : 'Save Budget'}
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="text-sm text-gray-600 italic">
              <p>Note: When your monthly spending exceeds the budget limit, you'll receive a notification.</p>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500">Failed to load budget information</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={fetchBudget}
            >
              Retry
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}