import React from 'react';

export default function Header() {
  return (
    <header className="relative w-full bg-cover bg-center h-48 flex items-center justify-center" 
            style={{backgroundImage: "url('https://images.unsplash.com/photo-1554768804-50c1e2b50a6e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')"}}>
      <div className="text-center text-white z-10">
        <h1 className="text-4xl md:text-5xl font-bold mb-1">ClearLedger</h1>
        <p className="text-xl">A Budget Calculating Website.</p>
      </div>
      <div className="absolute inset-0 bg-black opacity-40"></div>
    </header>
  );
}
