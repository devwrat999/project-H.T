import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";

interface BarChartProps {
  data: Array<{ name: string; value: number }>;
  dataKey?: string;
  xDataKey?: string;
  barColor?: string;
  width?: number | string;
  height?: number | string;
  legend?: boolean;
  grid?: boolean;
}

export function SimpleBarChart({
  data,
  dataKey = "value",
  xDataKey = "name",
  barColor = "hsl(var(--chart-1))",
  width = "100%",
  height = 300,
  legend = true,
  grid = true,
}: BarChartProps) {
  return (
    <ResponsiveContainer width={width} height={height}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
        {grid && <CartesianGrid strokeDasharray="3 3" vertical={false} />}
        <XAxis dataKey={xDataKey} axisLine={false} tickLine={false} />
        <YAxis axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{
            backgroundColor: "hsl(var(--background))",
            border: "1px solid hsl(var(--border))",
            borderRadius: "var(--radius)",
            boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
          }}
        />
        {legend && <Legend verticalAlign="bottom" height={36} />}
        <Bar dataKey={dataKey} fill={barColor} radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

interface PieChartProps {
  data: Array<{ name: string; value: number }>;
  colors?: string[];
  width?: number | string;
  height?: number | string;
  legend?: boolean;
  dataKey?: string;
  nameKey?: string;
  innerRadius?: number;
  outerRadius?: number;
}

export function SimplePieChart({
  data,
  colors = ["#0275d8", "#00b894", "#ffc107", "#fd7e14", "#6c757d", "#e83e8c"],
  width = "100%",
  height = 300,
  legend = true,
  dataKey = "value",
  nameKey = "name",
  innerRadius = 0,
  outerRadius = "80%",
}: PieChartProps) {
  return (
    <ResponsiveContainer width={width} height={height}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          innerRadius={innerRadius}
          outerRadius={outerRadius}
          fill="#8884d8"
          dataKey={dataKey}
          nameKey={nameKey}
          label={({ name, percent }) => 
            `${name}: ${(percent * 100).toFixed(0)}%`
          }
          labelLine={false}
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
          ))}
        </Pie>
        {legend && <Legend verticalAlign="bottom" height={36} />}
        <Tooltip
          formatter={(value) => [`₹${value}`, "Amount"]}
          contentStyle={{
            backgroundColor: "hsl(var(--background))",
            border: "1px solid hsl(var(--border))",
            borderRadius: "var(--radius)",
            boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
          }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}
