import { pgTable, text, serial, integer, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define our expense and order schemas using Drizzle schema
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  date: timestamp("date").notNull().defaultNow(),
  paymentId: text("payment_id"),
  orderId: text("order_id"),
  payee: text("payee"),
  note: text("note")
});

export const razorpayOrders = pgTable("razorpay_orders", {
  id: serial("id").primaryKey(),
  orderId: text("order_id").notNull().unique(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  status: text("status").notNull(),
  category: text("category").notNull(),
  payee: text("payee"),
  note: text("note"),
  createdAt: timestamp("created_at").notNull().defaultNow()
});

// Create insert schemas using drizzle-zod
export const insertExpenseSchema = createInsertSchema(expenses, {
  amount: z.union([z.string(), z.number()]) // Accept both string and number
}).pick({
  category: true,
  amount: true,
  date: true,
  paymentId: true,
  orderId: true,
  payee: true,
  note: true
});

export const insertRazorpayOrderSchema = createInsertSchema(razorpayOrders, {
  amount: z.union([z.string(), z.number()]) // Accept both string and number
}).pick({
  orderId: true,
  amount: true,
  currency: true,
  status: true,
  category: true,
  payee: true,
  note: true
});

// Budget settings schema
export const budgetSchema = z.object({
  limit: z.number().min(1, "Budget limit must be greater than 0"),
  month: z.number().min(0).max(11).optional(),
  year: z.number().optional()
});

// Export types for use in other places
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect & {
  // Our in-memory storage will have amount as number
  amount: number;
  payee: string | null;
  note: string | null;
};

export type InsertRazorpayOrder = z.infer<typeof insertRazorpayOrderSchema>;
export type RazorpayOrder = typeof razorpayOrders.$inferSelect & {
  // Our in-memory storage will have amount as number
  amount: number;
  payee: string | null;
  note: string | null;
};

export type BudgetSettings = z.infer<typeof budgetSchema>;
