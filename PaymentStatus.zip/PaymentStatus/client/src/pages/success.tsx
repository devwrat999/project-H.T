import { Link } from "wouter";
import { Check } from "lucide-react";
import { useEffect } from "react";

export default function SuccessPage() {
  useEffect(() => {
    // Update the document title when the component mounts
    document.title = "Payment Successful";

    // Reset the title when the component unmounts
    return () => {
      document.title = "Payment Status";
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 to-purple-600 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 text-center">
          <div className="flex justify-center">
            <div className="rounded-full bg-green-100 p-3">
              <Check className="h-16 w-16 text-green-500" strokeWidth={2} />
            </div>
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
            Payment Successful
          </h2>
          <p className="mt-2 text-lg text-gray-600">
            Thanks for the payment.
          </p>
          <div className="mt-6">
            <Link href="/">
              <a className="text-indigo-600 hover:text-indigo-500 font-medium">
                Return to Home
              </a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
