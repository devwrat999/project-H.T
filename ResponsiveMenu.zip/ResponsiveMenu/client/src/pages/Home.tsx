import QuickenMenu from "@/components/QuickenMenu";

const Home = () => {
  return (
    <div className="min-h-screen bg-white">
      <QuickenMenu />
      <main className="p-6 max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h1 className="text-2xl font-semibold text-gray-900 mb-4">
            Quicken Navigation Demo
          </h1>
          <p className="text-gray-600 mb-4">
            This is a demonstration of the Quicken navigation menu. Click the menu icon in the top-right corner to open the navigation menu.
          </p>
          <p className="text-gray-600">
            The menu system includes main navigation options with expandable submenus, matching the design and functionality of the Quicken application.
          </p>
        </div>
      </main>
    </div>
  );
};

export default Home;
