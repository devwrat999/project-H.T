import { Share, Bookmark, Menu } from "lucide-react";

interface QuickenHeaderProps {
  onMenuClick: () => void;
}

const QuickenHeader = ({ onMenuClick }: QuickenHeaderProps) => {
  return (
    <header className="bg-[#121212] text-white p-4 flex justify-between items-center relative z-20">
      <div className="flex items-center space-x-2">
        <div className="text-lg font-semibold text-white">Budget Cal...</div>
        <div className="text-sm text-gray-300">quicken.com</div>
      </div>
      <div className="flex items-center space-x-4">
        <button 
          className="text-white" 
          aria-label="Share"
        >
          <Share className="h-5 w-5" />
        </button>
        <button 
          className="text-white" 
          aria-label="Bookmark"
        >
          <Bookmark className="h-5 w-5" />
        </button>
        <button 
          className="text-white" 
          aria-label="Menu"
          onClick={onMenuClick}
        >
          <Menu className="h-6 w-6" />
        </button>
      </div>
    </header>
  );
};

export default QuickenHeader;
