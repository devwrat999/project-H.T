import { cn } from "@/lib/utils";
import { ChevronLeft } from "lucide-react";

interface SubMenuProps {
  id: string;
  isOpen: boolean;
  title: string;
  items: string[];
  sections?: { title: string; items: string[] }[];
  onBack: () => void;
}

const SubMenu = ({ id, isOpen, title, items, sections, onBack }: SubMenuProps) => {
  return (
    <div
      id={`${id}-submenu`}
      className={cn(
        "fixed top-0 right-0 bottom-0 w-full sm:w-80 bg-white z-50 transition-transform duration-300 ease-in-out",
        isOpen ? "translate-x-0" : "translate-x-full"
      )}
    >
      {/* Submenu header */}
      <div className="bg-[#f5f8fa] flex items-center p-4">
        <button
          className="mr-3 transition-transform duration-200 hover:-translate-x-1"
          aria-label="Back to main menu"
          onClick={onBack}
        >
          <ChevronLeft className="h-6 w-6 text-[#5f2eea]" />
        </button>
        <span className="text-gray-900 font-medium">{title}</span>
      </div>

      {/* Submenu content */}
      <div className="overflow-y-auto h-[calc(100%-56px)]">
        {sections ? (
          // Render with sections (for "I want to" menu)
          <>
            {sections.map((section, index) => (
              <div key={index}>
                <h2 className="px-6 py-4 text-[#5f2eea] font-semibold uppercase text-sm">
                  {section.title}
                </h2>
                <ul className="divide-y divide-gray-200">
                  {section.items.map((item, itemIndex) => (
                    <li
                      key={itemIndex}
                      className="py-4 px-6 cursor-pointer hover:bg-gray-50"
                    >
                      <span className="text-gray-900">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </>
        ) : (
          // Render without sections (for other menus)
          <ul className="divide-y divide-gray-200">
            {items.map((item, index) => (
              <li
                key={index}
                className="py-4 px-6 cursor-pointer hover:bg-gray-50"
              >
                <span className="text-gray-900">{item}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default SubMenu;
