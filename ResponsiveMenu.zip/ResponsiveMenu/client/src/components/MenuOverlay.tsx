import { cn } from "@/lib/utils";

interface MenuOverlayProps {
  isVisible: boolean;
  onClick: () => void;
}

const MenuOverlay = ({ isVisible, onClick }: MenuOverlayProps) => {
  return (
    <div 
      className={cn(
        "fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity duration-300",
        isVisible ? "opacity-100" : "opacity-0 pointer-events-none"
      )}
      onClick={onClick}
      aria-hidden={!isVisible}
    />
  );
};

export default MenuOverlay;
