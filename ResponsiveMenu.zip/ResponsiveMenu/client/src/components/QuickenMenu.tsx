import { useState } from "react";
import QuickenHeader from "./QuickenHeader";
import MenuOverlay from "./MenuOverlay";
import MainMenu from "./MainMenu";
import SubMenu from "./SubMenu";

// Define type for menu and submenu data
type SubMenuContent = {
  title: string;
  items: string[];
  sections?: { title: string; items: string[] }[];
};

type SubMenus = {
  [key: string]: SubMenuContent;
};

const QuickenMenu = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);

  // Submenu data based on screenshots
  const submenus: SubMenus = {
    "i-want-to": {
      title: "I want to",
      items: [],
      sections: [
        {
          title: "MANAGE MY PERSONAL FINANCES",
          items: [
            "Save more towards my goals",
            "Manage & reduce debt",
            "Build a financial safety net",
            "Stay on track with my budget",
            "See where my money is going",
            "Grown & diversify investments",
            "Plan for retirement",
          ],
        },
        {
          title: "MANAGE MY BUSINESS & RENTAL",
          items: [],
        },
      ],
    },
    "why-quicken": {
      title: "Why Quicken",
      items: ["Why Quicken", "Quicken vs. spreadsheets", "Quicken vs. free options"],
    },
    learn: {
      title: "Learn",
      items: ["Blog", "Investment research tool", "Financial calculators"],
    },
  };

  // Toggle main menu
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    if (!isMenuOpen) {
      setActiveSubmenu(null);
    }
  };

  // Open a specific submenu
  const openSubmenu = (menuId: string) => {
    setActiveSubmenu(menuId);
  };

  // Close the active submenu
  const closeSubmenu = () => {
    setActiveSubmenu(null);
  };

  return (
    <>
      <QuickenHeader onMenuClick={toggleMenu} />
      <MenuOverlay isVisible={isMenuOpen} onClick={toggleMenu} />
      <MainMenu
        isOpen={isMenuOpen}
        onClose={toggleMenu}
        onMenuItemClick={openSubmenu}
      />
      {Object.entries(submenus).map(([id, content]) => (
        <SubMenu
          key={id}
          id={id}
          isOpen={activeSubmenu === id}
          title={content.title}
          items={content.items}
          sections={content.sections}
          onBack={closeSubmenu}
        />
      ))}
    </>
  );
};

export default QuickenMenu;
