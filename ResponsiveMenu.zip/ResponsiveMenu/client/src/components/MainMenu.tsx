import { cn } from "@/lib/utils";
import { ChevronRight, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MainMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onMenuItemClick: (menuId: string) => void;
}

const MainMenu = ({ isOpen, onClose, onMenuItemClick }: MainMenuProps) => {
  const menuItems = [
    { id: "i-want-to", label: "I want to", hasSubmenu: true },
    { id: "why-quicken", label: "Why Quicken", hasSubmenu: true },
    { id: "plans-pricing", label: "Plans & pricing", hasSubmenu: false },
    { id: "learn", label: "Learn", hasSubmenu: true },
    { id: "support", label: "Support", hasSubmenu: false },
  ];

  return (
    <nav
      className={cn(
        "fixed top-0 right-0 bottom-0 w-full sm:w-80 bg-white z-40 transition-transform duration-300 ease-in-out",
        isOpen ? "translate-x-0" : "translate-x-full"
      )}
    >
      {/* Main menu header */}
      <div className="bg-[#121212] flex justify-between items-center p-4">
        <div className="text-[#5f2eea] text-2xl font-bold">Quicken</div>
        <button className="text-white p-1" aria-label="Close menu" onClick={onClose}>
          <X className="h-6 w-6" />
        </button>
      </div>

      {/* Main menu content */}
      <div className="overflow-y-auto h-[calc(100%-64px)]">
        <ul className="divide-y divide-gray-200">
          {menuItems.map((item) => (
            <li
              key={item.id}
              className="py-4 px-6 flex justify-between items-center cursor-pointer hover:bg-gray-50"
              onClick={() => item.hasSubmenu && onMenuItemClick(item.id)}
            >
              <span className="text-gray-900 font-medium">{item.label}</span>
              {item.hasSubmenu && (
                <ChevronRight className="h-5 w-5 text-gray-400" />
              )}
            </li>
          ))}
        </ul>

        <div className="p-6">
          <Button 
            className="w-full bg-[#5f2eea] hover:bg-purple-700 text-white font-medium py-3 px-4 rounded-md transition duration-200"
          >
            Get started
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default MainMenu;
